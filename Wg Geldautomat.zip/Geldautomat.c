#include <time.h>
// Selbstdefiniert Header-Files stehen im Projektpfad
// sie werden mit "..." eingebunden
#include "Geldautomat.h"

// Beschreibung: Funktion zur �berpr�fung der Kontonummer
// Name: kto_nr_pruefen(int ktNr)
// �bergabeparamter: Kontonummer
// R�ckgabeparamter: die Stelle des Kunden im Kundenarray bzw. NOk falls ung�ltige KtoNr
int kto_nr_pruefen(tKunde * kunden , unsigned int ktNr, unsigned int groesse)
{
// lokale Variable f�r den R�ckgabewert
    int i=0, ret = NOK;
    // pr�fen der Ktonummern
    // Debugausgaben zur Anzeige des Rechenergebnis
    for(i=0; i< groesse; i++)
    {
        // geht beides
        // if ( (*(kunden+i)).ktoNr == ktoNr )
        if ( (kunden + i)->ktoNr == ktNr )
        {
            // den Index der KtoNr zur�ckliefern
            ret = i;
            #ifdef DEBUG
                printf("Kto Nr OK an der Stelle %i \n", i);
            #endif
            // beendet die for-Schleife
            break;
        }
    }
// Ergebnis der Pr�fung zur�ckliefern
    return ret;
}


// Beschreibung: Funktion zur �berpr�fung der PIN
// Name:
// �bergabeparamter:    Zeiger auf das Kunden-Array
//                      Stelle des zu �berpr�fenden Kunden im Array
//                      die zu �berpr�fende PIN
// R�ckgabeparamter:    OK oder NOK
int Pin_pruefen(tKunde * kunden, int arraySt, int Pin)
{
    int ret = NOK;
    if (Pin == (kunden + arraySt)->PIN )
    {
        ret = OK;
    }
    return ret;
}


// Funktion zur �berpr�fung des gew�nschten Geldbetrags
int BetragPruefen (int betrag)
{
    int ret = NOK;
    // wenn der Betrag durch 5 teilbar ist
    if ( (betrag%5) == 0 && betrag <= MAX_BETRAG && betrag > 0)
    {
        ret = OK;
    }
    return ret;
}

// Funktion zur Gedlscheinberechnung
void Geldscheinausgabe (int betrag, unsigned int *scheine, unsigned int groesse)
{
    int zwischenergebnis=0, i=0;
    while (betrag != 0)
    {
        // Berechnung der Anzahl von Scheinen beginnend mit dem
        // gr��ten Schein (array index 0 ist der gr��te Schein)
        zwischenergebnis = betrag / scheine[i];
        printf("Anzahl der %der Scheine:  %d\n" ,scheine [i], zwischenergebnis);
        // den Restbetrag berechnen
        betrag -= (zwischenergebnis * scheine[i]);
        i++;
    }
    // auch die restlichen kleinen Scheine noch ausgeben!!!
    while (i < groesse)
    {
        printf("Anzahl der %der Scheine: %d\n" ,scheine [i],0);
        i++;
    }

}

// Funktion f�llt das Kunden Array mit Zufallswerten f�r Kontonummer und PIN
void erzeuge_ktoNrs_pins(tKunde * kunden, unsigned int groesse)
{
    int i;
    /* Zufallsgenerator initialisieren */
    srand(time(NULL));
    // 5 Kontonummern 5 stellig
    for ( i=0; i<groesse; i++ )
    {
        // rand liefert eine ganzzahlige Zufallszahl im Bereich von 0 und 2^15 - 1
        // Zufallskontonummer erzeugen
        (kunden + i)->ktoNr = (rand() %89999 + 1) + 10000;
        // ZufallsPIN erzeugen
        // WICHTIG: die PINs beginnen beim Offset groesse
        (kunden + i)->PIN = ( rand() %899 + 1) + 100;
    }
}



// Beschreibung: Funktion zur Ausgabe der Kundendaten
// Name: alle_kundendaten_ausgeben
// �bergabeparamter:
// erste Paramter ist der Zeiger auf das auszugebene Kunden-Array
// zweiter Paramter ist Gr��e des Arrays
// R�ckgabeparamter: -
void alle_kundendaten_ausgeben(tKunde * kunden)
{
        // Name und Vorname
        printf("Kunde: Name: %s: Vorname: %s ",(kunden)->Name,  (kunden)->Vorname );
        // die Kontonummern
        printf("- KtoNr: %i - ",(kunden)->ktoNr  );
        // die PINs
        printf("PIN: %i",(kunden)->PIN );
        // die Saldi
        printf(" - Saldo: %.2f",(kunden)->Saldo );
        printf("\n");
}


// Beschreibung: Funktion2 zur Ausgabe der Kundendaten
// Name: name_saldo_ausgeben
// �bergabeparamter:
// erste Paramter ist der Zeiger auf das auszugebene Kunden-Array
// zweiter Paramter ist Gr��e des Arrays
// R�ckgabeparamter: -
void name_saldo_ausgeben(tKunde * kunden)
{
        // Name und Vorname
        printf("Kunde: Name: %s: Vorname: %s ",(kunden)->Name,  (kunden)->Vorname );
        // die Saldi
        printf(" - Saldo: %.2f",(kunden)->Saldo );
        printf("\n");
}


// Beschreibung: Funktion1 zur Ausgabe der Kundendaten
// Name: name_ktoNr_PIN_ausgeben
// �bergabeparamter:
// erste Paramter ist der Zeiger auf das auszugebene Kunden-Array
// zweiter Paramter ist Gr��e des Arrays
// R�ckgabeparamter: -
void name_ktoNr_PIN_ausgeben(tKunde * kunden)
{
        // Name und Vorname
        printf("Kunde: Name: %s: Vorname: %s ",(kunden)->Name,  (kunden)->Vorname );
        // die Kontonummern
        printf("- KtoNr: %i - ",(kunden)->ktoNr  );
        // die PINs
        printf("PIN: %i",(kunden)->PIN );
        printf("\n");
}


// Beschreibung: Funktion zur Ausgabe der Kundendaten
// Name: kundendaten_ausgeben
// �bergabeparamter:
// erste Paramter ist der Zeiger auf das auszugebene Kunden-Array
// zweiter Paramter ist Gr��e des Arrays
// R�ckgabeparamter: -
void kundendaten_ausgeben(tKunde * kunden, unsigned int groesse)
{
    int i = 0;
        printf("Die Kontonummern und PINs: \n");
    for ( i=0; i<groesse; i++ )
    {
        // Name und Vorname
        printf("Kunde %i: Name: %s: Vorname: %s ",i ,(kunden + i )->Name,  (kunden + i )->Vorname );
        // die Kontonummern
        printf("- KtoNr: %i - ",(kunden + i )->ktoNr  );
        // die PINs
        printf("PIN: %i",(kunden + i )->PIN );
        // die Saldi
        printf(" - Saldo: %.2f",(kunden + i)->Saldo );
        printf("\n");
    }
}
