// Pr�prozessor Direktiven
#ifndef GELDAUTOMAT_H_INCLUDED
#define GELDAUTOMAT_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Definition symbolischer Konstanten
// kann der Kunde hier im Header File anpassen
#define MAX_BETRAG 10000
#define OK 1
#define NOK -1
#define DEBUG
#define ANZAHL_KUNDEN 3
#define ZUL_PIN_VERSUCHE 3
#define SCHEINE 500, 200, 100, 50, 20, 10, 5
// #define WARTUNGSMODUS

// globale Datenstrukturen
struct TKunde
{
    char Name[20];
    char Vorname[20];
    unsigned int ktoNr;
    unsigned int PIN;
    float Saldo;
    void (*fptr_daten_abfrage) ( struct TKunde *);
};

typedef struct TKunde tKunde;

// Funktionsdeklarationen
// die Variablennamen m�ssen hier nicht angegeben werden, die nur zur Verdeutlichung anegeben

// erste Paramter ist ein Zeiger auf das Kunden-Array
// zweite Paramter ist die zu �berpr�fende Kontonummer
// dritte Paramter ist die Gr��e des Kundenarrays
int kto_nr_pruefen ( tKunde * kunden , unsigned int ktoNr, unsigned int groesse );
// erste Paramter ist ein Zeiger auf das Kunden-Array
// zweite Paramter ist die Stelle der zu �berpr�fenden PIN
// dritte Paramter ist die zu �berpr�fende PIN
int Pin_pruefen(tKunde * kunden, int arraySt, int Pin);
 // Funktion zur �berpr�fung des gew�nschten Geldbetrags
int BetragPruefen (int betrag);
// Funktion zur Gedlscheinberechnung
void Geldscheinausgabe (int betrag, unsigned int * scheine, unsigned int groesse);
// void fuelle_kto_pin_array(unsigned int * ktNrsPins, unsigned int groesse);
void erzeuge_ktoNrs_pins(tKunde * kunden, unsigned int groesse);
// Funktion zur Ausgabe der Kundendaten
void alle_kundendaten_ausgeben(tKunde * kunden);
void name_saldo_ausgeben(tKunde * kunden);
void name_ktoNr_PIN_ausgeben(tKunde * kunden);
void kundendaten_ausgeben(tKunde * kunden, unsigned int groesse);


#endif // GELDAUTOMAT_H_INCLUDED
