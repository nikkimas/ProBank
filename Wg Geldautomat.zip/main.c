// Selbstdefiniert Header-Files stehen im Projektpfad
// sie werden mit "..." eingebunden
#include "Geldautomat.h"


// das Hauptprogramm, schreibt der User selbst
int main()
{
// lokale Variablen definieren
    int summe, pin_versuche, pin;
    int ktoNr, index_kunde;
    char in;

    //lokale Variablen
    unsigned int scheine[] = {SCHEINE};
    // lokales Kunden-Array
    // ktoNrs[zeilen][spalten]
    tKunde kunden[ANZAHL_KUNDEN];

    // den Kunden Namen und Saldi zuweisen
    strcpy(kunden[0].Name, "Clemens");
    strcpy(kunden[0].Vorname, "Thomas");
    kunden[0].Saldo  = 50000.00;

    strcpy(kunden[1].Name, "Loewen");
    strcpy(kunden[1].Vorname, "Andreas");
    kunden[1].Saldo = 70000.00;

    strcpy(kunden[2].Name, "Pelrick");
    strcpy(kunden[2].Vorname, "Olaf");
    kunden[2].Saldo = 100000.00;

    // Kontonummern und PINs generieren
    erzeuge_ktoNrs_pins(&kunden[0],  sizeof(kunden)/sizeof(tKunde) );
    // alle Kundendaten zur ausgeben
    #ifdef DEBUG
    kundendaten_ausgeben( &kunden[0],  sizeof(kunden)/sizeof(tKunde) );
    #endif // DEBUG


// Endlosschleife
    while (1)
    {
// das Men�
        printf( "\n************************************************** \n");
        printf( "Der Geldautomat der bank 007 \n");
        printf( "\n************************************************** \n");

        // Kontonummer einlesen
        printf( "Bitte schieben Sie Ihre Karte ein (KtoNr eingeben) \n");
        // Eonlesen der KtoNr
        scanf("%d",&ktoNr);
        fflush(stdin);

        index_kunde = kto_nr_pruefen(&kunden[0],ktoNr, sizeof(kunden)/sizeof(tKunde));
        if (index_kunde != NOK)
        {
            //Start der Schleife zum Einlesen und Pr�fen der PIN, falls KtoNr vorhanden
            printf("Ihre KtoNr ist gueltig an der Stelle %d\n", index_kunde);
            pin_versuche = 0;
            // PIN-Eingabe
            while (pin_versuche < ZUL_PIN_VERSUCHE )
            {
                printf("Geben Sie Ihre PIN ein: \n");
                //Einlesen der PIN:
                scanf("%i",&pin);
                fflush(stdin);
                pin_versuche++;
                // Funktionsaufruf: Pr�fung der PIN
                pin = Pin_pruefen(&kunden[0],index_kunde, pin);
                if (pin!=NOK)
                {
                    printf("Ihre PIN ist gueltig\n");
                    break;
                }
                else
                {
                    printf("Die PIN ist ungueltig\n");
                }
            }
            if (pin_versuche < ZUL_PIN_VERSUCHE)
            {
                printf("Was moechten Sie tun?\n A = Geld abheben - I = Informationen - X = Abbruch\n");
                scanf("%c",&in);
                fflush(stdin);
                switch (in)
                {
                case 'A':
                case 'a':
                    printf( "Wie viel Geld soll ausgezahlt werden?\n");
                    scanf("%d",&summe);
                    fflush(stdin);
                    if (BetragPruefen (summe) == OK)
                    {
                        // jetzt den gew�nschten Betrag auszahlen
                        printf( "Betrag OK  Geld wird ausgezahlt.\n \n");
                        Geldscheinausgabe(summe,&scheine[0],sizeof(scheine)/sizeof(unsigned int));
                    }
                    else
                    {
                        printf( "Ung\x81ltiger Betrag. Konto wurde gesperrt.\n \n");
                    }
                    break;

                case 'I':
                case 'i':
                    printf( "Welche Daten moechten Sie ausgeben?\n - A = alle - S = Saldo - K = KtoNr und PIN \n");
                    scanf("%c",&in);
                    fflush(stdin);
                    // den Funktionspointer zur Datenabfrage initialisieren
                    // Nachteil: man muss jetzt f�r jeden Kunden die Funktion explizit definieren
                    // Vorteil: man k�nnte jetzt f�r jeden Kunden individuell die Ausgabefunktion gestalten
                    switch (in)
                    {
                    case 'A':
                    case 'a':
                        kunden[index_kunde].fptr_daten_abfrage = &alle_kundendaten_ausgeben;
                        kunden[index_kunde].fptr_daten_abfrage(&kunden[index_kunde]);
                        break;
                    case 'S':
                    case 's':
                        kunden[index_kunde].fptr_daten_abfrage = &name_saldo_ausgeben;
                        kunden[index_kunde].fptr_daten_abfrage(&kunden[index_kunde]);
                        break;

                    case 'K':
                    case 'k':
                        kunden[index_kunde].fptr_daten_abfrage = &name_ktoNr_PIN_ausgeben;
                        kunden[index_kunde].fptr_daten_abfrage(&kunden[index_kunde]);
                        break;

                    default:
                        break;

                    }
                    break;

                case 'X':
                case 'x':
                    printf( "Vorgag wurde vom User abgebrochen \n");
                    break;

                default:
                    printf( "Unguelitge Einagbe \n");
                    break;
                }
        }  // end of g�ltige PIN
        // Fall ung�ltige PIN
        else
        {
            printf( "PIN drei mal falsch eingegeben \n");
            printf( "Vorgang wird abgebrochen \n");
        }
    } // end of g�ltige Kontonummer
    // hier beginnt der Wartungsmodus
#ifdef WARTUNGSMODUS
    else if (ktoNr == 0)
    {
        // erst mal den Bildschirm l�schen
        system("cls");
        printf("Sie befinden sich im Wartungsmodus\n");
        printf("Welche Wartung wollen Sie vornehmen?\n");
        printf("(1:KtoNr Ausgabe, 2:KtoNr aufst. sortieren, 3:KtoNr abst. sortieren 4:Ausgabe Geldscheine): \n");
        scanf("%c", &in);
        switch (in)
        {
        case '1':
            printf("Ausgabe der Kontonummern und PINs: \n");
            ktoNrs_PINs_ausgeben(&ktoNrsPins[0][0], ANZAHL_KTO_NRS);
            break;
        case '2':
            printf("Aufsteigende Sortierung der Kontonummern und PINs: \n");
            SortKtoNrsPINsAsc(&ktoNrsPins[0][0]);
            // ausgeben der sortierten Liste
            ktoNrs_PINs_ausgeben(&ktoNrsPins[0][0], ANZAHL_KTO_NRS);
            break;
        case '3':
            printf("Abfsteigende Sortierung der Kontonummern und PINs: \n");
            SortKtoNrsPINsDesc(&ktoNrsPins[0][0]);
            // ausgeben der sortierten Liste
            ktoNrs_PINs_ausgeben(&ktoNrsPins[0][0], ANZAHL_KTO_NRS);
            break;
        case '4':
            printf("Ausgabe der Geldscheine: \n");
            AusgabeVorhGeldscheine(&scheine[0]);
            break;
        default:
            printf("Ung�ltiger Wartungsmodus !");
        }

    }  // end of Wartungsmodus
#endif // WARTUNGSMODUS
    else
    {
        // ung�ltige Karte bzw. falsche Kontonummer
        printf( "Ungueltige Kontonummer! \n Der Vorgang wird abgebrochen\n");
    }
} // end of while(1)
return 0;
}   // end of main()
